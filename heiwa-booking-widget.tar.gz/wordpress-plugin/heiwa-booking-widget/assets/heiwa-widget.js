/**
 * Heiwa Booking Widget - WordPress JavaScript
 * Minimal integration script for WordPress
 */

(function() {
    'use strict';

    // Configuration
    var config = {
        apiEndpoint: 'http://localhost:3005/api', // Change this to your admin domain
        apiKey: 'heiwa_wp_test_key_2024_secure_deployment', // Change this to your API key
        widgetId: 'heiwa-widget-wp-shortcode-' + Math.random().toString(36).substr(2, 9)
    };

    // Global configuration for React widget
    window.heiwaWidgetConfig = config;

    /**
     * Initialize widget when DOM is ready
     */
    function initializeWidget() {
        console.log('🎯 Heiwa Widget: WordPress configuration loaded', {
            buildId: 'wordpress-integration',
            restBase: config.apiEndpoint,
            widgetId: config.widgetId
        });

        // Add event listeners to booking buttons
        var buttons = document.querySelectorAll('.heiwa-book-button, [data-heiwa-widget]');
        buttons.forEach(function(button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                openBookingWidget();
            });
        });

        // Add shortcode support
        var shortcodeElements = document.querySelectorAll('.heiwa-booking-shortcode');
        shortcodeElements.forEach(function(element) {
            element.innerHTML = '<button class="heiwa-book-button" onclick="window.heiwaOpenWidget()"><span>📅</span> Book Now</button>';
        });
    }

    /**
     * Open the booking widget
     */
    function openBookingWidget() {
        // Create modal overlay
        var overlay = document.createElement('div');
        overlay.className = 'heiwa-modal-overlay';
        overlay.innerHTML = `
            <div class="heiwa-modal-content">
                <button class="heiwa-close-button" onclick="this.parentElement.parentElement.remove()">×</button>
                <div style="padding: 40px; text-align: center;">
                    <h2 style="color: #333; margin-bottom: 20px;">Book Your Surf Adventure</h2>
                    <div class="heiwa-spinner"></div>
                    <p style="color: #666; margin-top: 20px;">Loading booking widget...</p>
                    <div class="heiwa-error" style="display: none;"></div>
                </div>
            </div>
        `;

        // Add loading functionality
        setTimeout(function() {
            // Simulate loading the React widget
            var content = overlay.querySelector('.heiwa-modal-content div');
            content.innerHTML = `
                <button class="heiwa-close-button" onclick="this.parentElement.parentElement.remove()">×</button>
                <div style="padding: 40px;">
                    <h2 style="color: #333; margin-bottom: 20px;">Choose Your Adventure</h2>
                    <div style="display: grid; gap: 20px; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));">
                        <div style="border: 2px solid #e5e7eb; border-radius: 12px; padding: 24px; text-align: center;">
                            <h3 style="color: #1f2937; margin-bottom: 12px;">Book a Room</h3>
                            <p style="color: #6b7280; margin-bottom: 16px;">Choose your dates and accommodation. Perfect for flexible stays.</p>
                            <div style="font-size: 24px; font-weight: bold; color: #059669; margin-bottom: 16px;">From €45</div>
                            <button class="heiwa-book-button" onclick="alert('Room booking feature coming soon!')">Select Room Booking</button>
                        </div>
                        <div style="border: 2px solid #e5e7eb; border-radius: 12px; padding: 24px; text-align: center;">
                            <h3 style="color: #1f2937; margin-bottom: 12px;">All-Inclusive Surf Week</h3>
                            <p style="color: #6b7280; margin-bottom: 16px;">Join our structured surf camp programs with coaching and community.</p>
                            <div style="font-size: 24px; font-weight: bold; color: #059669; margin-bottom: 16px;">From €599</div>
                            <button class="heiwa-book-button" onclick="alert('Surf week booking feature coming soon!')">Select Surf Week</button>
                        </div>
                    </div>
                    <div style="text-align: center; margin-top: 30px; color: #6b7280; font-size: 14px;">
                        <em>Full React widget integration requires admin dashboard connection</em>
                    </div>
                </div>
            `;
        }, 1000);

        document.body.appendChild(overlay);
    }

    /**
     * Global function to open widget (for shortcodes)
     */
    window.heiwaOpenWidget = openBookingWidget;

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeWidget);
    } else {
        initializeWidget();
    }

    // Re-initialize on AJAX content updates (for themes that use AJAX)
    if (typeof jQuery !== 'undefined') {
        jQuery(document).on('ajaxComplete', function() {
            initializeWidget();
        });
    }

})();
