import React from 'react';
import { createRoot } from 'react-dom/client';
import { ConsolidatedWidget } from '../ConsolidatedWidget';

export function mountWidget(root: HTMLElement, props: any = {}) {
  const reactRoot = createRoot(root);
  reactRoot.render(<ConsolidatedWidget {...props} />);
}
