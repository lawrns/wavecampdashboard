import { mountWidget } from './mount';

class HeiwaBookingWidget extends HTMLElement {
  private shadow: ShadowRoot;
  private widgetRoot: HTMLElement;

  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: 'open' });

    // Create widget container
    this.widgetRoot = document.createElement('div');
    this.widgetRoot.className = 'heiwa-widget-container';

    // Inject styles
    const style = document.createElement('style');
    style.textContent = `
      /* Tailwind CSS base styles */
      *, ::before, ::after {
        box-sizing: border-box;
      }

      /* Surf enhancements CSS */
      .surf-card {
        background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
      }

      .surf-button-primary {
        background: linear-gradient(135deg, #f97316 0%, #ea580c 100%);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 12px 24px;
        font-weight: 600;
        transition: all 0.3s ease;
      }

      .surf-button-primary:hover {
        background: linear-gradient(135deg, #ea580c 0%, #dc2626 100%);
        transform: translateY(-1px);
        box-shadow: 0 8px 25px rgba(249, 115, 22, 0.3);
      }
    `;

    this.shadow.appendChild(style);
    this.shadow.appendChild(this.widgetRoot);
  }

  connectedCallback() {
    // Get configuration from window.heiwaWidgetConfig and element attributes
    const windowConfig = (window as any).heiwaWidgetConfig || {};
    const elementConfig = {
      type: this.getAttribute('data-type') || windowConfig.type || 'standalone',
      position: this.getAttribute('data-position') || windowConfig.position || 'right',
      primaryColor: this.getAttribute('data-primary-color') || windowConfig.primaryColor || '#f97316',
      triggerText: this.getAttribute('data-trigger-text') || windowConfig.triggerText || 'BOOK NOW',
      showLandingPage: this.hasAttribute('data-show-landing') || windowConfig.showLandingPage || false,
      apiEndpoint: windowConfig.apiEndpoint,
      apiKey: windowConfig.apiKey,
      config: windowConfig // Pass full config for WordPress integration
    };

    // Mount the widget
    mountWidget(this.widgetRoot, elementConfig);
  }
}

// Register the custom element
customElements.define('heiwa-booking-widget', HeiwaBookingWidget);
