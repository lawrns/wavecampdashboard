<?php
/**
 * Plugin Name: Heiwa Booking Widget
 * Plugin URI: https://heiwahouse.com
 * Description: React-powered booking widget that provides the full booking experience
 * Version: 2.0.0
 * Author: Heiwa House
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('HEIWA_BOOKING_VERSION', '2.0.0');
define('HEIWA_BOOKING_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('HEIWA_BOOKING_PLUGIN_URL', plugin_dir_url(__FILE__));

class Heiwa_Booking_Widget_Shortcode {
    
    public function __construct() {
        add_shortcode('heiwa_booking', array($this, 'render_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        error_log('Heiwa Booking Widget: Shortcode class initialized');
    }
    
    public function enqueue_assets() {
        static $assets_enqueued = false;
        if ($assets_enqueued) {
            return;
        }
        $assets_enqueued = true;

        $asset_url  = HEIWA_BOOKING_PLUGIN_URL . 'assets/build';
        $asset_path = HEIWA_BOOKING_PLUGIN_DIR . 'assets/build';
        $bundle_handle = 'heiwa-booking-widget-umd';
        $bundle_file   = 'heiwa-widget.umd.js';

        // Enqueue widget CSS
        wp_enqueue_style(
            'heiwa-booking-widget-tailwind',
            $asset_url . '/heiwa-widget.tailwind.css',
            array(),
            HEIWA_BOOKING_VERSION
        );
        wp_enqueue_style(
            'heiwa-booking-widget-surf',
            $asset_url . '/heiwa-widget.surf.css',
            array('heiwa-booking-widget-tailwind'),
            HEIWA_BOOKING_VERSION
        );

        // Enqueue the React widget bundle
        wp_enqueue_script(
            $bundle_handle,
            $asset_url . '/' . $bundle_file,
            array('wp-element'), // WordPress includes React as wp-element
            HEIWA_BOOKING_VERSION,
            true
        );

        $admin_api_base = getenv('HEIWA_ADMIN_API_BASE') ?: 'http://localhost:3005/api';
        $admin_api_key = getenv('HEIWA_ADMIN_API_KEY') ?: 'heiwa_wp_test_key_2024_secure_deployment';

        $config = array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('heiwa_widget_nonce'),
            'restBase' => rest_url('heiwa/v1'),
            'pluginUrl' => HEIWA_BOOKING_PLUGIN_URL,
            'buildId' => 'wp-widget-' . time(),
            'settings' => array(
                'apiEndpoint' => $admin_api_base,
                'apiKey' => $admin_api_key,
            )
        );

        wp_localize_script($bundle_handle, 'heiwaWidgetConfig', $config);
        wp_add_inline_script($bundle_handle, "window.heiwaWidgetConfig = ".json_encode($config).";", 'before');
        
        error_log('Heiwa Booking Widget: Assets enqueued');
    }

    public function render_shortcode($atts) {
        $this->enqueue_assets();

        $tailwind_css_path = HEIWA_BOOKING_PLUGIN_DIR . 'assets/build/heiwa-widget.tailwind.css';
        $surf_css_path = HEIWA_BOOKING_PLUGIN_DIR . 'assets/build/heiwa-widget.surf.css';

        $styles = '';
        if (file_exists($tailwind_css_path)) {
            $styles .= file_get_contents($tailwind_css_path);
        }
        if (file_exists($surf_css_path)) {
            $styles .= file_get_contents($surf_css_path);
        }

        $widget_id = 'heiwa-widget-' . wp_generate_uuid4();

        $output = '<style>' . $styles . '</style>';
        $output .= '<div id="' . esc_attr($widget_id) . '" class="heiwa-booking-widget-container"></div>';

        return $output;
    }
}

function heiwa_booking_widget_init() {
    error_log('Heiwa Booking Widget: Plugin initializing');
    new Heiwa_Booking_Widget_Shortcode();
    error_log('Heiwa Booking Widget: Plugin initialized');
}

add_action('plugins_loaded', 'heiwa_booking_widget_init');

error_log('Heiwa Booking Widget: Plugin file loaded');
