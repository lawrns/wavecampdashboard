import { build } from "esbuild";
import path from "path";
import fs from "fs";

async function main() {
  const projectRoot = process.cwd();
  const outFile = path.join(projectRoot, "heiwa-react-widget/assets/build/heiwa-widget.web.js");
  const outDir = path.dirname(outFile);
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  await build({
    entryPoints: [path.join(projectRoot, "wordpress-plugin/src/web-component.tsx")],
    bundle: true,
    format: "iife",
    platform: "browser",
    outfile: outFile,
    sourcemap: false,
    minify: true,
    jsx: "automatic",
    external: ["react", "react-dom"],
    define: { 
      "process.env.NODE_ENV": '"production"',
      global: "window"
    },
    banner: {
      js: `/**
 * Heiwa Booking Widget Web Component
 * Version: 2.0.0
 * Isolated React widget for WordPress integration
 */`
    }
  });

  console.log("✅ Built Web Component:", outFile);
}

main().catch(console.error);
